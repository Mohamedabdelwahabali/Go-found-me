package com.example.go_find_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
