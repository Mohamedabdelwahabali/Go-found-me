import 'dart:convert';

import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/modules/go_find_me/models/trusted_people.dart';

class User extends Equatable {
  final String name;
  final String email;
  final String password;
  final DateTime birthdate;
  final bool emailVerified;
  final String phoneNumber;
  final String gender;
  final String avatar;
  final trustedPerson trusted;
  final String userid;

  User({
    @required this.name,
    @required this.email,
    @required this.password,
    @required this.birthdate,
    @required this.emailVerified,
    @required this.phoneNumber,
    @required this.gender,
    @required this.avatar,
    this.trusted,
    @required this.userid,
  });

  @override
  List<Object> get props => [
        name,
        email,
        password,
        birthdate,
        emailVerified,
        phoneNumber,
        gender,
        avatar,
        trusted,
        userid,
      ];

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'password': password,
      'birthdate': birthdate.millisecondsSinceEpoch,
      'emailVerified': emailVerified,
      'phoneNumber': phoneNumber,
      'gender': gender,
      'avatar': avatar,
      'userid': userid,
      'trusted': trusted.toMap(),
    };
  }

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      name: map['name'],
      email: map['email'],
      password: map['password'],
      birthdate: DateTime.fromMillisecondsSinceEpoch(map['birthdate']),
      emailVerified: map['emailVerified'],
      phoneNumber: map['phoneNumber'],
      gender: map['gender'],
      avatar: map['avatar'],
      userid: map['userid'],
      trusted: trustedPerson.fromMap(map['trusted']),
    );
  }

  String toJson() => json.encode(toMap());

  factory User.fromJson(String source) => User.fromMap(json.decode(source));
}

List<User> users = [
  User(
    name: "Ahmed Mohamed",
    email: "fake212@gmail.com",
    password: "GG33@gg",
    birthdate: DateTime.now(),
    emailVerified: true,
    phoneNumber: "+20109999626",
    gender: 'Male',
    avatar:
        "https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg",
    userid: "1slkdfj1klj32421",
  ),
  User(
    name: "Hoda Mohssen",
    email: "fake313@gmail.com",
    password: "DD33@hh",
    birthdate: DateTime.now(),
    emailVerified: true,
    phoneNumber: "+20102199212",
    gender: 'Female',
    avatar:
        "https://cdn.vox-cdn.com/thumbor/wcsS4QxE6taJFT3HGaze1Rnietw=/0x0:2040x1360/1200x800/filters:focal(857x517:1183x843)/cdn.vox-cdn.com/uploads/chorus_image/image/63947858/jbareham_181010_2989_0323.0.jpg",
    userid: "1slkdfj1kljsfsdfsdf32421",
  ),
  User(
    name: "Mohaned Mohamed",
    email: "fake313@gmail.com",
    password: "DD33@hh",
    birthdate: DateTime.now(),
    emailVerified: true,
    phoneNumber: "+20102199212",
    gender: 'Male',
    avatar:
        "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    userid: "1slkdfj1k902k3dfsdf32421",
  ),
  User(
    name: "Shokalata",
    email: "fake313@gmail.com",
    password: "DD33@hh",
    birthdate: DateTime.now(),
    emailVerified: true,
    phoneNumber: "+20102199212",
    gender: 'Female',
    avatar:
        "https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg.jpg",
    userid: "a93j230",
  ),
];

User currentUser = User(
  name: "Emma Phillips",
  email: "emma.phillips323@gmail.com",
  password: "DD33@hh",
  birthdate: DateTime.now(),
  emailVerified: true,
  phoneNumber: "+20102192212",
  gender: 'Female',
  avatar:
      "https://images.unsplash.com/photo-1623096210953-29e4077a94a8?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=3900&q=80",
  userid: "923j90j120j12lsdf",
);
