import 'dart:convert';

import 'package:flutter/cupertino.dart';

class UserNotification {
  final String sendid;
  final String content;
  final DateTime date;

  UserNotification({
    @required this.sendid,
    @required this.content,
    @required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'sendid': sendid,
      'content': content,
      'date': date.millisecondsSinceEpoch,
    };
  }

  factory UserNotification.fromMap(Map<String, dynamic> map) {
    return UserNotification(
      sendid: map['sendid'],
      content: map['content'],
      date: DateTime.fromMillisecondsSinceEpoch(map['date']),
    );
  }

  String toJson() => json.encode(toMap());

  factory UserNotification.fromJson(String source) =>
      UserNotification.fromMap(json.decode(source));
}

List<UserNotification> notifications = [
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hi",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1klj32421",
    content: "Comment on your post",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hi",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hiiiiiiiiiiiiiiiii",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1k902k3dfsdf32421",
    content: "Add new post",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1k902k3dfsdf32421",
    content: "Uploaded photo on missing people",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "a93j230",
    content: "Found her child",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hi",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1klj32421",
    content: "Comment on your post",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hi",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1kljsfsdfsdf32421",
    content: "Hiiiiiiiiiiiiiiiii",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1k902k3dfsdf32421",
    content: "Add new post",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "1slkdfj1k902k3dfsdf32421",
    content: "Uploaded photo on missing people",
    date: DateTime.now(),
  ),
  UserNotification(
    sendid: "a93j230",
    content: "Found her child",
    date: DateTime.now(),
  ),
];
