import 'dart:convert';

import 'package:flutter/cupertino.dart';

class PostLocation {
  final String city;
  final String region;

  PostLocation({
    @required this.city,
    @required this.region,
  });

  Map<String, dynamic> toMap() {
    return {
      'city': city,
      'region': region,
    };
  }

  factory PostLocation.fromMap(Map<String, dynamic> map) {
    return PostLocation(
      city: map['city'],
      region: map['region'],
    );
  }

  String toJson() => json.encode(toMap());

  factory PostLocation.fromJson(String source) =>
      PostLocation.fromMap(json.decode(source));
}
