import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:go_find_me/modules/go_find_me/models/post.dart';
import 'package:go_find_me/widgets/post.dart';

// ignore: must_be_immutable
class HomeScreen extends StatelessWidget {
  HomeScreen({Key key}) : super(key: key);
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final picker = ImagePicker();
  File _image;
  List cities;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Container(
        padding: EdgeInsets.only(left: 30, right: 30, top: 3.0),
        height: MediaQuery.of(context).size.height * 0.81,
        child: ListView.separated(
          physics: BouncingScrollPhysics(),
          itemBuilder: (context, index) => PostWidget(post: myposts[index]),
          separatorBuilder: (context, index) => SizedBox(height: 20),
          itemCount: myposts.length,
        ),
      ),
      floatingActionButton: FloatingActionButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        backgroundColor: Theme.of(context).primaryColor,
        child: Icon(Icons.add_a_photo_sharp),
        onPressed: () async {
          _image = await _imgFromCamera();
          if (_image != null) print(_image);
          // Navigator.of(context).pop();
        },
      ),
    );
  }

  // ignore: missing_return
  Future<File> _imgFromCamera() async {
    final pickedFile = await picker.getImage(source: ImageSource.camera);
    if (pickedFile != null) return File(pickedFile.path);
  }
}
