import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:go_find_me/utils/mixins/validation_mixins.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class ProfileEditScreen extends StatefulWidget {
  ProfileEditScreen({Key key}) : super(key: key);

  @override
  _ProfileEditScreenState createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(elevation: 0.0),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: Container(
              width: MediaQuery.of(context).size.width,
              color: Theme.of(context).primaryColor,
              child: Column(
                children: [
                  CircleAvatar(
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 45.0,
                      //////////////////////////////////////////////////////// edit
                      backgroundImage: NetworkImage(
                        "https://images.unsplash.com/photo-1623096210953-29e4077a94a8?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=3900&q=80",
                      ),
                    ),
                    radius: 50,
                    backgroundColor: Colors.white,
                  ),
                  SizedBox(height: 10),
                  Text(
                    //////////////////////////////////////////////////////// edit
                    "Emma Phillips",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                      // shadows:
                    ),
                  ),
                  //////////////////////////////////////////////////////// edit
                  Text(
                    "emma.phillips323@gmail.com",
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white60,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 200,
            bottom: 0,
            left: 30,
            right: 30,
            child: Form(
              key: _formKey,
              autovalidateMode: AutovalidateMode.onUserInteraction,
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    keyboardType: TextInputType.name,
                    autocorrect: false,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.person_rounded,
                        color: Theme.of(context).primaryColor,
                      ),
                      labelStyle: TextStyle(
                        color: Theme.of(context).primaryColor,
                      ),
                      labelText: "Name",
                    ),
                    validator: Validators.isValidUserName,
                    onChanged: (name) {
                      _nameController.text = name;
                      _nameController.selection = TextSelection.fromPosition(
                        TextPosition(
                          offset: _nameController.text.length,
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 15),
                  TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    autocorrect: false,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(
                        color: Theme.of(context).primaryColor,
                      ),
                      prefix: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(
                          "+20",
                          style: TextStyle(
                            color: Theme.of(context).primaryColor,
                          ),
                        ),
                      ),
                      prefixIcon: Icon(
                        Icons.phone_android_rounded,
                        color: Theme.of(context).primaryColor,
                      ),
                      labelText: "Phone Number",
                    ),
                    validator: Validators.isValidPhoneNumber,
                    onChanged: (phone) {
                      _phoneController.text = phone;
                      _phoneController.selection = TextSelection.fromPosition(
                        TextPosition(
                          offset: _phoneController.text.length,
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 15),
                  SizedBox(
                    height: 52,
                    child: DropdownSearch(
                      mode: Mode.MENU,
                      maxHeight: 120,
                      showSelectedItem: true,
                      dropdownSearchDecoration: InputDecoration(
                        labelStyle: TextStyle(
                          color: Theme.of(context).primaryColor,
                        ),
                        suffixIcon: Icon(
                          Icons.arrow_drop_down_rounded,
                          size: 30,
                          color: Theme.of(context).primaryColor,
                        ),
                        isDense: true,
                        prefixIcon: Icon(
                          FontAwesomeIcons.transgender,
                          color: Theme.of(context).primaryColor,
                        ),
                        labelText: "Gender",
                      ),
                      dropDownButton: SizedBox.shrink(),
                      items: ["Male", "Female"],
                      hint: "gender in menu mode",
                      onChanged: print,
                      selectedItem: "Male",
                    ),
                  ),
                  SizedBox(height: 15),
                  DateTimeField(
                    format: DateFormat("MMM d, yyyy"),
                    controller: _dateController,
                    decoration: InputDecoration(
                      labelStyle: TextStyle(
                        color: Theme.of(context).primaryColor,
                      ),
                      prefixIcon: Icon(
                        Icons.date_range,
                        color: Theme.of(context).primaryColor,
                      ),
                      hintText: "May 2, 2020",
                      labelText: "Birthday",
                    ),
                    onShowPicker: (context, currentValue) {
                      return showDatePicker(
                        context: context,
                        firstDate: DateTime(1900),
                        initialDate: currentValue ?? DateTime.now(),
                        lastDate: DateTime(2100),
                      );
                    },
                  ),
                  SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    child: FloatingActionButton(
                      child: Text(
                        "Edit",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                      backgroundColor: Color(0xff202C44),
                      onPressed: () {},
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _dateController.dispose();
    super.dispose();
  }
}
