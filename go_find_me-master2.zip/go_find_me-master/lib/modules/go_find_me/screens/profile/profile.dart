import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/modules/go_find_me/models/post.dart';
import 'package:go_find_me/modules/go_find_me/models/user.dart';
import 'package:go_find_me/modules/go_find_me/screens/profile/edit_profile.dart';
import 'package:go_find_me/widgets/post.dart';

// import 'cubit/profile_cubit.dart';
// import 'edit_profile.dart';

class ProfileScreen extends StatelessWidget {
  User user;
  ProfileScreen({Key key, @required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Theme.of(context).primaryColor,
      appBar: AppBar(
        elevation: 0.0,
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfileEditScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: Container(
              width: MediaQuery.of(context).size.width,
              color: Theme.of(context).primaryColor,
              child: Column(
                children: [
                  CircleAvatar(
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 45.0,
                      backgroundImage: NetworkImage(user.avatar),
                    ),
                    radius: 50,
                    backgroundColor: Colors.white,
                  ),
                  SizedBox(height: 10),
                  Text(
                    user.name,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                      // shadows:
                    ),
                  ),
                  Text(
                    user.email,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white60,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 194,
            left: 0,
            right: 0,
            child: CircleAvatar(
              radius: 10,
              backgroundColor: Colors.white,
            ),
          ),
          Positioned(
            top: 200,
            left: 0,
            right: 0,
            height: 100,
            child: Container(
              color: Colors.white,
              child: Center(
                child: Container(
                  height: 50,
                  width: 1,
                  color: Theme.of(context).primaryColor,
                ),
              ),
            ),
          ),
          Positioned(
            top: 200,
            left: 0.0,
            right: 0.0,
            height: 100,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      //////////////////////////////////////////////////////// edit
                      myposts.length.toString(),
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).primaryColor,
                        // shadows:
                      ),
                    ),
                    Text(
                      "Reports",
                      style: TextStyle(
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      myposts.length > 0
                          ? myposts
                              .map((e) => e.isFound ? 1 : 0)
                              .toList()
                              .reduce((a, b) => a + b)
                              .toString()
                          : '0',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w500,
                        color: Theme.of(context).primaryColor,
                        // shadows:
                      ),
                    ),
                    Text(
                      "Found",
                      style: TextStyle(
                        color: Colors.black54,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          Positioned(
            top: 300,
            left: 0,
            right: 0,
            bottom: 0,
            child: buildImages(),
          )
        ],
      ),
    );
  }

  Widget buildImages() => ListView.separated(
        padding: EdgeInsets.symmetric(
          horizontal: 30.0,
          vertical: 5.0,
        ),
        itemBuilder: (context, index) => PostWidget(post: myposts[index]),
        separatorBuilder: (context, index) => SizedBox(height: 20),
        itemCount: myposts.length,
      );
}
