import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_conditional_rendering/conditional.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:go_find_me/modules/go_find_me/models/address/city.dart';
import 'package:go_find_me/modules/go_find_me/models/address/governorate.dart';
import 'package:go_find_me/modules/go_find_me/screens/report/bloc/report_bloc.dart';
import 'package:go_find_me/modules/layout/layout.dart';
import 'package:go_find_me/utils/mixins/validation_mixins.dart';
import 'package:go_find_me/utils/ui/dialogs/image_alert_dialog.dart';
import 'package:image_picker/image_picker.dart';

import 'package:intl/intl.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({Key key}) : super(key: key);

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _typeController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();

  final picker = ImagePicker();
  final TextEditingController _imageController = TextEditingController();

  final TextEditingController _governorateController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  String _governorateId = '1';
  int _cityIndex = 0;
  ReportBloc _reportBloc;
  bool isButtonEnabled(ReportState state) => state.isPopulated;

  @override
  void initState() {
    super.initState();
    _reportBloc = BlocProvider.of<ReportBloc>(context);
    _nameController.addListener(_onNameChange);
    _descriptionController.addListener(_onDescriptionChange);
    _typeController.addListener(_onTypeChange);
    _ageController.addListener(_onAgeChange);
    _imageController.addListener(_onImageChange);
    _genderController.addListener(_onGenderChange);
    _dateController.addListener(_onDateChange);
    _governorateController.addListener(_onGovernorateChange);
    _cityController.addListener(_onCityChange);
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ReportBloc, ReportState>(
      listener: (context, state) {
        if (state is ReportStateSuccess) {
          // ScaffoldMessenger.of(context).showSnackBar(
          //   ReportSubmittingSnackBar(context: context),
          // );
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => AppLayout()),
          );
        }

        // if (state is ReportStateFailure) Navigator.pop(context);
      },
      child: BlocBuilder<ReportBloc, ReportState>(
        builder: (context, state) {
          return Conditional.single(
            context: context,
            conditionBuilder: (BuildContext context) =>
                state is ReportStateLoading,
            widgetBuilder: (BuildContext context) => Center(
              child: SizedBox(
                height: 300,
                width: 300,
                child: CircularProgressIndicator(),
              ),
            ),
            fallbackBuilder: (BuildContext context) => Scaffold(
              appBar: AppBar(
                title: Text("Share post"),
                actions: [
                  MaterialButton(
                      child: Text(
                        "Post",
                        style: TextStyle(
                          color: state.isPopulated ? Colors.white : Colors.grey,
                        ),
                      ),
                      onPressed: state.isPopulated
                          ? () {
                              _onFormSubmitted();
                            }
                          : null)
                ],
              ),
              body: Container(
                padding: EdgeInsets.only(
                  left: 20,
                  right: 20,
                ),
                child: SingleChildScrollView(
                  physics: BouncingScrollPhysics(),
                  child: Form(
                    key: _formKey,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        // vertical: 20.0,
                        horizontal: 20.0,
                      ),
                      child: Column(
                        children: [
                          SizedBox(height: 10),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Upload Image",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8.0),
                              _imageController.text.isEmpty
                                  ? GestureDetector(
                                      child: SizedBox(
                                        height: 200,
                                        child: DottedBorder(
                                          color: Theme.of(context)
                                              .primaryColor
                                              .withOpacity(0.5),
                                          dashPattern: [15, 6],
                                          strokeWidth: 1.0,
                                          child: Center(
                                            child: SizedBox(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.6,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Icon(
                                                    Icons
                                                        .add_photo_alternate_outlined,
                                                    size: 50,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      onTap: () async {
                                        await showImageAlertdialog(context);
                                        _imageController.text =
                                            await _imgFromGallery();
                                      },
                                    )
                                  : ClipRRect(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0)),
                                      child: Stack(
                                        children: [
                                          Image.file(
                                            File(_imageController.text),
                                            fit: BoxFit.fitWidth,
                                          ),
                                          Positioned(
                                            top: 10,
                                            right: 10,
                                            child: IconButton(
                                              icon: Icon(
                                                FontAwesomeIcons.times,
                                                color: Colors.red,
                                              ),
                                              onPressed: () {
                                                _imageController.text = '';
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            ],
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Post Category",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.redAccent,
                                      size: 10,
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 52,
                                  child: DropdownSearch<String>(
                                    mode: Mode.MENU,
                                    maxHeight: 120,
                                    showSelectedItem: true,
                                    dropdownSearchDecoration: InputDecoration(
                                      suffixIcon: Icon(
                                        Icons.arrow_drop_down_rounded,
                                        size: 30,
                                        color: Theme.of(context).primaryColor,
                                      ),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(10.0),
                                        ),
                                      ),
                                      isDense: true,
                                      // hintText: "Amgad Hussein Ahmed",
                                    ),
                                    dropDownButton: SizedBox.shrink(),
                                    items: ["Missing", "Finding"],
                                    hint: "Missing/Finding",
                                    onChanged: (type) {
                                      _typeController.text = type;
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Name",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                TextFormField(
                                  controller: _nameController,
                                  keyboardType: TextInputType.name,
                                  autocorrect: false,
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0)),
                                    ),
                                    hintText: "Amgad Hussein Ahmed",
                                  ),
                                  onChanged: (name) {
                                    _nameController.text = name;
                                    _nameController.selection =
                                        TextSelection.fromPosition(
                                      TextPosition(
                                        offset: _nameController.text.length,
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Gender",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.redAccent,
                                      size: 10,
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 52,
                                  child: DropdownSearch<String>(
                                    mode: Mode.MENU,
                                    maxHeight: 120,
                                    showSelectedItem: true,
                                    dropdownSearchDecoration: InputDecoration(
                                      suffixIcon: Icon(
                                        Icons.arrow_drop_down_rounded,
                                        size: 30,
                                        color: Theme.of(context).primaryColor,
                                      ),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(10.0),
                                        ),
                                      ),
                                      isDense: true,
                                      // hintText: "Amgad Hussein Ahmed",
                                    ),
                                    dropDownButton: SizedBox.shrink(),
                                    items: ["Male", "Female"],
                                    hint: "Male/Female",
                                    onChanged: (gender) {
                                      _genderController.text = gender;
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Age",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.redAccent,
                                      size: 10,
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 52,
                                  child: DropdownSearch(
                                    mode: Mode.DIALOG,
                                    maxHeight: 400,
                                    showSelectedItem: true,
                                    dropdownSearchDecoration: InputDecoration(
                                      suffixIcon: Icon(
                                        Icons.arrow_drop_down_rounded,
                                        size: 30,
                                        color: Theme.of(context).primaryColor,
                                      ),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(10.0),
                                        ),
                                      ),
                                      isDense: true,
                                    ),
                                    dropDownButton: SizedBox.shrink(),
                                    hint: "15",
                                    items: [
                                      for (var i = 1; i < 71; i += 1)
                                        i.toString()
                                    ],
                                    onChanged: (age) {
                                      _ageController.text = age;
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Missing Date",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: (_typeController.text == "Missing")
                                        ? Colors.black
                                        : Colors.black26,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  height: 52,
                                  child: DateTimeField(
                                    format: DateFormat("MMM d, yyyy"),
                                    enabled: _typeController.text == "Missing",
                                    controller: _dateController,
                                    decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10.0)),
                                      ),
                                      hintText: "May 2, 2020",
                                    ),
                                    onShowPicker: (context, currentValue) {
                                      return showDatePicker(
                                        context: context,
                                        firstDate: DateTime(1900),
                                        initialDate:
                                            currentValue ?? DateTime.now(),
                                        lastDate: DateTime(2100),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Governorate",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.redAccent,
                                      size: 10,
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 52,
                                  child: FutureBuilder<List<Governorate>>(
                                    future: BlocProvider.of<ReportBloc>(context)
                                        .governorates(context),
                                    builder: (context, snapshot) {
                                      if (snapshot.hasData)
                                        _governorateController.text = snapshot
                                            .data[int.parse(_governorateId) - 1]
                                            .governorateNameEnglish;

                                      return DropdownSearch(
                                        mode: Mode.DIALOG,
                                        maxHeight: 400,
                                        showSelectedItem: true,
                                        selectedItem:
                                            _governorateController.text,
                                        dropdownSearchDecoration:
                                            InputDecoration(
                                          suffixIcon: Icon(
                                            Icons.arrow_drop_down_rounded,
                                            size: 30,
                                            color:
                                                Theme.of(context).primaryColor,
                                          ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(10.0),
                                            ),
                                          ),
                                          isDense: true,
                                        ),
                                        dropDownButton: SizedBox.shrink(),
                                        showSearchBox: true,
                                        searchBoxDecoration: InputDecoration(
                                          suffixIcon: Icon(
                                            Icons.search_sharp,
                                            size: 30,
                                            color:
                                                Theme.of(context).primaryColor,
                                          ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(10.0),
                                            ),
                                          ),
                                          isDense: true,
                                        ),
                                        items: snapshot.hasData
                                            ? snapshot.data
                                                .map(
                                                  (e) =>
                                                      e.governorateNameEnglish,
                                                )
                                                .toList()
                                            : null,
                                        onChanged: (governorate) {
                                          _governorateController.text =
                                              governorate;
                                          _governorateId = snapshot
                                              .data[snapshot.data.indexWhere(
                                            (element) =>
                                                element
                                                    .governorateNameEnglish ==
                                                governorate,
                                          )]
                                              .id;
                                          _cityIndex = 0;
                                          _cityController.text = '';
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            height: 80.0,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "City",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Icon(
                                      Icons.star,
                                      color: Colors.redAccent,
                                      size: 10,
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 52,
                                  child: FutureBuilder<List<City>>(
                                    future: BlocProvider.of<ReportBloc>(context)
                                        .governorateCities(
                                      context,
                                      _governorateId,
                                    ),
                                    builder: (context, snapshot) {
                                      if (snapshot.hasData) {
                                        _cityController.text = snapshot
                                            .data[_cityIndex].cityNameEnglish;
                                      }

                                      return DropdownSearch(
                                        mode: Mode.DIALOG,
                                        maxHeight: 400,
                                        showSelectedItem: true,
                                        dropdownSearchDecoration:
                                            InputDecoration(
                                          suffixIcon: Icon(
                                            Icons.arrow_drop_down_rounded,
                                            size: 30,
                                            color:
                                                Theme.of(context).primaryColor,
                                          ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(10.0),
                                            ),
                                          ),
                                          isDense: true,
                                        ),
                                        dropDownButton: SizedBox.shrink(),
                                        showSearchBox: true,
                                        searchBoxDecoration: InputDecoration(
                                          suffixIcon: Icon(
                                            Icons.search_sharp,
                                            size: 30,
                                            color:
                                                Theme.of(context).primaryColor,
                                          ),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.all(
                                              Radius.circular(10.0),
                                            ),
                                          ),
                                          isDense: true,
                                        ),
                                        items: snapshot.hasData
                                            ? snapshot.data.map((e) {
                                                return e.cityNameEnglish;
                                              }).toList()
                                            : null,
                                        selectedItem: _cityController.text,
                                        onChanged: (city) {
                                          _cityController.text = city;

                                          _cityIndex = snapshot.data.indexWhere(
                                            (element) =>
                                                element.cityNameEnglish == city,
                                          );
                                        },
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Description",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 7),
                              TextFormField(
                                controller: _descriptionController,
                                keyboardType: TextInputType.multiline,
                                maxLines: null,
                                autocorrect: false,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10.0)),
                                  ),
                                ),
                                validator: Validators.isValidUserName,
                                onChanged: (description) {
                                  _descriptionController.text = description;
                                  _descriptionController.selection =
                                      TextSelection.fromPosition(
                                    TextPosition(
                                      offset:
                                          _descriptionController.text.length,
                                    ),
                                  );
                                },
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    _reportBloc = BlocProvider.of<ReportBloc>(context);
    _nameController.dispose();
    _descriptionController.dispose();
    _typeController.dispose();
    _ageController.dispose();
    _genderController.dispose();
    _dateController.dispose();
    _imageController.dispose();
    _governorateController.dispose();
    _cityController.dispose();
  }

  void _onNameChange() {
    _reportBloc.add(ReportNameChange(name: _nameController.text));
  }

  void _onDescriptionChange() {
    _reportBloc.add(ReportDescriptionChange(
      description: _descriptionController.text,
    ));
  }

  void _onTypeChange() {
    _reportBloc.add(ReportTypeChange(type: _typeController.text));
  }

  void _onGenderChange() {
    _reportBloc.add(ReportGenderChange(gender: _genderController.text));
  }

  void _onAgeChange() {
    _reportBloc.add(ReportAgeChange(age: int.parse(_ageController.text)));
  }

  void _onDateChange() {
    _reportBloc
        .add(ReportDateChange(date: DateTime.parse(_dateController.text)));
  }

  void _onImageChange() {
    _reportBloc.add(ReportImageChange(image: _imageController.text));
  }

  void _onGovernorateChange() {
    _reportBloc
        .add(ReportGovernorateChange(governorate: _governorateController.text));
  }

  void _onCityChange() {
    _reportBloc.add(ReportCityChange(city: _cityController.text));
  }

  void _onFormSubmitted() {
    _reportBloc.add(
      ReportSubmitted(
        name: _nameController.text,
        type: _typeController.text,
        description: _descriptionController.text,
        gender: _genderController.text,
        age: int.parse(_ageController.text),
        date: _dateController.text.isNotEmpty
            ? DateFormat("MMM d, yyyy").parse(_dateController.text)
            : null,
        governorate: _governorateController.text,
        city: _cityController.text,
        image: _imageController.text,
      ),
    );
  }

  // ignore: missing_return
  Future<String> _imgFromGallery() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    if (pickedFile != null) return pickedFile.path;
  }
}
