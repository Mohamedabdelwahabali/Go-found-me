import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MiTrackerScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "MiTracker",
        style: TextStyle(
          fontSize: 50,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
