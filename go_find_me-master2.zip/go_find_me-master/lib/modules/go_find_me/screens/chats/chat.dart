import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_conditional_rendering/conditional.dart';
import 'package:go_find_me/modules/go_find_me/models/message.dart';
import 'package:go_find_me/modules/go_find_me/models/user.dart';
import 'package:go_find_me/modules/go_find_me/screens/chats/chat_details.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Conditional.single(
      context: context,
      conditionBuilder: (context) => true,
      widgetBuilder: (context) {
        Message lastMessage = chats
            .reduce((curr, next) => curr.date.isAfter(next.date) ? curr : next);

        User chatWith = users
            .firstWhere((element) => element.userid == lastMessage.reciverId);

        return ListView.separated(
          physics: BouncingScrollPhysics(),
          itemBuilder: (context, index) => ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(chatWith.avatar),
            ),
            // user name
            title: Text(chatWith.name),
            subtitle: Text(
              lastMessage.content,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: Text(DateFormat("MMM d, yyyy").format(lastMessage.date)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatDetailsScreen(
                    messages: chats,
                    chatWith: chatWith,
                  ),
                ),
              );
            },
          ),
          // buildChatItem(SocialCubit.get(context).users[index], context),
          separatorBuilder: (context, index) => Divider(),
          itemCount: 1,
        );
      },
      fallbackBuilder: (context) => Center(child: CircularProgressIndicator()),
    );
  }
}

List<Message> chats = [
  Message(
    reciverId: '923j90j120j12lsdf',
    senderId: '1slkdfj1klj32421',
    image: null,
    content: 'hi',
    date: DateTime.now(),
    mid: 'h2934h20h234902',
  ),
  Message(
    image: null,
    content: 'Emma!!',
    reciverId: '923j90j120j12lsdf',
    senderId: '1slkdfj1klj32421',
    date: DateTime.now(),
    mid: 'dsuf09quu2039u4j20',
  ),
  Message(
    image: null,
    reciverId: '1slkdfj1klj32421',
    senderId: '923j90j120j12lsdf',
    content: 'sorry, who are you?',
    date: DateTime.now(),
    mid: '0923h4023yh82hy984h23',
  ),
  Message(
    reciverId: '923j90j120j12lsdf',
    senderId: '1slkdfj1klj32421',
    image: null,
    content: 'I\'m ahmed your friend',
    date: DateTime.now(),
    mid: 'salkfj9203j32ilk12',
  ),
  Message(
    reciverId: '1slkdfj1klj32421',
    senderId: '923j90j120j12lsdf',
    image: null,
    content: 'ok.',
    date: DateTime.now(),
    mid: '3298h2i3h98h32hskdljf',
  ),
];
