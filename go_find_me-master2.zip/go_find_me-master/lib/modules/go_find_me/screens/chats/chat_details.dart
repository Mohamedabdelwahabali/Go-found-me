import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/modules/go_find_me/models/message.dart';
import 'package:go_find_me/modules/go_find_me/models/user.dart';

class ChatDetailsScreen extends StatelessWidget {
  final List<Message> messages;
  final User chatWith;
  ChatDetailsScreen({key, @required this.messages, @required this.chatWith})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    TextEditingController _messageController = TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text(chatWith.name),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height - 100,
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(
              fit: FlexFit.tight,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    for (int index = 0; index < messages.length; index++)
                      messageBuilder(context, index),
                  ],
                ),
              ),
            ),
            TextFormField(
              controller: _messageController,
              maxLines: null,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                    // borderRadius: new BorderRadius.circular(25.0),
                    ),
                hintText: 'type your message here ...',
                suffixIcon: IconButton(
                  icon: Icon(
                    Icons.send,
                    color: Theme.of(context).primaryColor,
                  ),
                  onPressed: () {},
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget messageBuilder(context, index) {
    if (messages[index].senderId == currentUser.userid)
      return Column(
        children: [
          buildMyMessage(messages[index], context),
          SizedBox(height: 10),
        ],
      );
    return Column(
      children: [
        messageView(messages[index]),
        SizedBox(height: 10),
      ],
    );
  }

  Widget messageView(Message message) {
    return Align(
      alignment: AlignmentDirectional.centerStart,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[300],
          borderRadius: BorderRadiusDirectional.only(
            bottomEnd: Radius.circular(
              10.0,
            ),
            topStart: Radius.circular(
              10.0,
            ),
            topEnd: Radius.circular(
              10.0,
            ),
          ),
        ),
        padding: EdgeInsets.symmetric(
          vertical: 5.0,
          horizontal: 10.0,
        ),
        child: Text(
          message.content,
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }

  Widget buildMyMessage(Message message, BuildContext context) {
    return Align(
      alignment: AlignmentDirectional.centerEnd,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(
                .2,
              ),
          borderRadius: BorderRadiusDirectional.only(
            bottomStart: Radius.circular(
              10.0,
            ),
            topStart: Radius.circular(
              10.0,
            ),
            topEnd: Radius.circular(
              10.0,
            ),
          ),
        ),
        padding: EdgeInsets.symmetric(
          vertical: 5.0,
          horizontal: 10.0,
        ),
        child: Text(
          message.content,
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
