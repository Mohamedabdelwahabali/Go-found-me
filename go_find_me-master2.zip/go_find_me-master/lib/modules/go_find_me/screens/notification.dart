import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/modules/go_find_me/models/notification.dart';
import 'package:go_find_me/modules/go_find_me/models/user.dart';
import 'package:go_find_me/widgets/notification_list_tile.dart';

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: BouncingScrollPhysics(),
      children: notifications.map(
        (notification) {
          User user = users[users
              .indexWhere((element) => element.userid == notification.sendid)];
          return notificationListTile(
            username: user.name,
            image: user.avatar,
            content: notification.content,
            onTap: () {},
          );
        },
      ).toList(),
    );
  }
}
