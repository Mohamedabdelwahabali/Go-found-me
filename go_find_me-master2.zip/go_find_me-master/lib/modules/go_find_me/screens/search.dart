import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/modules/go_find_me/models/post.dart';
import 'package:go_find_me/widgets/post.dart';

class SearchScreen extends StatelessWidget {
  TextEditingController _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 30,
        title: SizedBox(
          height: 34.0,
          child: TextFormField(
            controller: _searchController,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              hintText: "Search",
              hintStyle: TextStyle(
                fontSize: 16,
                color: Colors.black54,
                letterSpacing: 1.5,
              ),
              contentPadding: EdgeInsets.symmetric(
                vertical: 0.0,
                horizontal: 10,
              ),
              border: OutlineInputBorder(
                borderSide: BorderSide(
                  width: 0.0,
                  style: BorderStyle.none,
                ),
              ),
              suffixIcon: Icon(Icons.search),
            ),
            onChanged: (text) {
              print(text);
            },
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
        child: ListView.separated(
          physics: BouncingScrollPhysics(),
          itemBuilder: (context, index) => PostWidget(post: myposts[index]),
          separatorBuilder: (context, index) => SizedBox(height: 20),
          itemCount: myposts.length,
        ),
      ),
    );
  }
}
