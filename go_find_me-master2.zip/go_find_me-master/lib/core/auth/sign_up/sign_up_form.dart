// import 'package:bloc_provider/bloc_provider.dart';
import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_find_me/utils/mixins/validation_mixins.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';

class SignUpForm extends StatefulWidget {
  SignUpForm({Key key}) : super(key: key);

  @override
  _SignUpFormState createState() => _SignUpFormState();
}

class _SignUpFormState extends State<SignUpForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextFormField(
              controller: _nameController,
              keyboardType: TextInputType.name,
              autocorrect: false,
              decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.person_rounded,
                  color: Theme.of(context).primaryColor,
                ),
                labelStyle: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
                labelText: "Name",
              ),
              validator: Validators.isValidUserName,
              onChanged: (name) {
                _nameController.text = name;
                _nameController.selection = TextSelection.fromPosition(
                  TextPosition(
                    offset: _nameController.text.length,
                  ),
                );
              },
            ),
            SizedBox(height: 15),
            TextFormField(
              controller: _emailController,
              keyboardType: TextInputType.name,
              autocorrect: false,
              decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.email,
                  color: Theme.of(context).primaryColor,
                ),
                labelStyle: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
                labelText: "Email Address",
              ),
              validator: Validators.isValidEmail,
              onChanged: (email) {
                _emailController.text = email.trim();
                _emailController.selection = TextSelection.fromPosition(
                  TextPosition(
                    offset: _emailController.text.length,
                  ),
                );
              },
            ),
            SizedBox(height: 15),
            TextFormField(
              controller: _passwordController,
              keyboardType: TextInputType.visiblePassword,
              obscureText: true,
              autocorrect: false,
              decoration: InputDecoration(
                labelText: "Password",
                labelStyle: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
                prefixIcon: Icon(
                  Icons.https,
                  color: Theme.of(context).primaryColor,
                ),
              ),
              validator: Validators.isValidPassword,
              onChanged: (password) {
                _passwordController.text = password;
                _passwordController.selection = TextSelection.fromPosition(
                  TextPosition(
                    offset: _passwordController.text.length,
                  ),
                );
              },
            ),
            SizedBox(height: 15),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              autocorrect: false,
              decoration: InputDecoration(
                labelStyle: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
                prefix: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    "+20",
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ),
                prefixIcon: Icon(
                  Icons.phone_android_rounded,
                  color: Theme.of(context).primaryColor,
                ),
                labelText: "Phone Number",
              ),
              validator: Validators.isValidPhoneNumber,
              onChanged: (phone) {
                _phoneController.text = phone;
                _phoneController.selection = TextSelection.fromPosition(
                  TextPosition(
                    offset: _phoneController.text.length,
                  ),
                );
              },
            ),
            SizedBox(height: 15),
            SizedBox(
              height: 52,
              child: DropdownSearch(
                mode: Mode.MENU,
                maxHeight: 120,
                showSelectedItem: true,
                dropdownSearchDecoration: InputDecoration(
                  labelStyle: TextStyle(
                    color: Theme.of(context).primaryColor,
                  ),
                  suffixIcon: Icon(
                    Icons.arrow_drop_down_rounded,
                    size: 30,
                    color: Theme.of(context).primaryColor,
                  ),
                  isDense: true,
                  prefixIcon: Icon(
                    FontAwesomeIcons.transgender,
                    color: Theme.of(context).primaryColor,
                  ),
                  labelText: "Gender",
                ),
                dropDownButton: SizedBox.shrink(),
                items: ["Male", "Female"],
                hint: "gender in menu mode",
                onChanged: print,
                selectedItem: "Male",
              ),
            ),
            SizedBox(height: 15),
            DateTimeField(
              format: DateFormat("MMM d, yyyy"),
              controller: _dateController,
              decoration: InputDecoration(
                labelStyle: TextStyle(
                  color: Theme.of(context).primaryColor,
                ),
                prefixIcon: Icon(
                  Icons.date_range,
                  color: Theme.of(context).primaryColor,
                ),
                hintText: "May 2, 2020",
                labelText: "Birthday",
              ),
              onShowPicker: (context, currentValue) {
                return showDatePicker(
                  context: context,
                  firstDate: DateTime(1900),
                  initialDate: currentValue ?? DateTime.now(),
                  lastDate: DateTime(2100),
                );
              },
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: FloatingActionButton(
                child: Text(
                  "SIGN UP",
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                backgroundColor: Color(0xff202C44),
                onPressed: () {},
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _dateController.dispose();
    super.dispose();
  }
}
