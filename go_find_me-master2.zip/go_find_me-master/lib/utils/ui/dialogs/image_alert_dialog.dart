import 'package:flutter/material.dart';

Future<void> showImageAlertdialog(context) async {
  return await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      contentPadding: EdgeInsets.all(0.0),
      title: Text('Notify'),
      content: SingleChildScrollView(
        child: ListBody(
          children: [
            Container(
              child: Text(
                "The face should be clear, not too small in the photo, sideways away from the camera, or upside down.",
              ),
              padding: EdgeInsets.fromLTRB(24.0, 20.0, 24.0, 24.0),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          child: Text("OK"),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ],
    ),
  );
}
