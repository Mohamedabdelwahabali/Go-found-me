import 'package:flutter/material.dart';

Widget drawerListTile({
  @required IconData icon,
  @required String text,
  onTap,
}) =>
    Builder(
      builder: (context) => ListTile(
        minLeadingWidth: 10,
        dense: true,
        leading: Icon(icon, color: Colors.white),
        title: Text(
          text,
          style: TextStyle(color: Colors.white),
        ),
        onTap: onTap,
      ),
    );
