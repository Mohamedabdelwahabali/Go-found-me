import 'package:flutter/material.dart';

Widget notificationListTile({
  @required String image,
  @required String username,
  @required String content,
  onTap,
}) =>
    ListTile(
      minLeadingWidth: 10,
      dense: true,
      leading: CircleAvatar(
        backgroundImage: NetworkImage(image),
      ),
      title: Text(
        username,
        // style: TextStyle(color: Colors.white),
      ),
      subtitle: Text(content),
      onTap: onTap,
    );
