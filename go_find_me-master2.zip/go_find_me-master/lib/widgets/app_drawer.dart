import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:go_find_me/core/auth/sign_in/sign_in.dart';
import 'package:go_find_me/modules/go_find_me/models/user.dart';
import 'package:go_find_me/modules/go_find_me/screens/profile/profile.dart';
import 'package:go_find_me/widgets/drawer_list_tile.dart';

Widget appDrawer(@required BuildContext context, @required User user) {
  return Drawer(
      child: Container(
    color: Theme.of(context).primaryColor,
    child: ListView(
      physics: BouncingScrollPhysics(),
      children: [
        Container(
          height: 100,
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 20),
          color: Colors.white,
          child: ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(user.avatar),
              radius: 40,
            ),
            title: Text(
              user.name,
              style: Theme.of(context).textTheme.headline6,
            ),
          ),
        ),
        drawerListTile(
          icon: Icons.person,
          text: "Account",
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfileScreen(user: user),
              ),
            );
          },
        ),
        Divider(
          thickness: 2,
          height: 1,
          color: Colors.white10,
        ),
        drawerListTile(
          icon: Icons.pin_drop_rounded,
          text: "Mi Tracker",
          onTap: () {},
        ),
        drawerListTile(
          icon: Icons.help,
          text: "Help & Support",
          onTap: () {},
        ),
        drawerListTile(
          icon: Icons.settings_rounded,
          text: "Setting & Privacy",
          onTap: () {},
        ),
        drawerListTile(
          icon: Icons.exit_to_app_rounded,
          text: "Sign out",
          onTap: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (_) => SignInScreen(),
              ),
            );
          },
        ),
      ],
    ),
  ));
}
