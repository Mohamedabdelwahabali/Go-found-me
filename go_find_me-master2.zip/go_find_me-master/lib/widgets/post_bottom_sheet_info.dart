import 'package:dropdown_search/dropdown_search.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_find_me/modules/go_find_me/models/address/city.dart';
import 'package:go_find_me/modules/go_find_me/models/address/governorate.dart';
import 'package:go_find_me/modules/go_find_me/models/post.dart';
import 'package:go_find_me/modules/go_find_me/screens/report/bloc/report_bloc.dart';

void showFilterBottomSheet({
  @required BuildContext context,
  @required List<Post> posts,
}) {
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _governorateController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  String _governorateId = '1';
  int _cityIndex = 0;

  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10.0),
    ),
    builder: (builder) {
      return BlocBuilder<ReportBloc, ReportState>(
        builder: (context, state) => SizedBox(
          height: 500,
          child: Stack(
            children: [
              Positioned(
                top: 0,
                left: 15,
                right: 15,
                height: 60,
                child: Column(
                  children: [
                    Container(
                      width: 40,
                      height: 4,
                      margin: EdgeInsets.only(top: 10, bottom: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(2),
                        color: Colors.grey,
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Filter",
                          style: TextStyle(fontSize: 20),
                        ),
                        GestureDetector(
                          child: Icon(
                            Icons.close,
                            color: Colors.redAccent,
                          ),
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                        )
                      ],
                    ),
                    Divider(),
                  ],
                ),
              ),
              Positioned(
                top: 60,
                left: 30,
                right: 30,
                bottom: 0,
                child: Column(
                  children: [
                    SizedBox(
                      height: 80.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Gender",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 52,
                            child: DropdownSearch<String>(
                              mode: Mode.MENU,
                              maxHeight: 120,
                              showSelectedItem: true,
                              dropdownSearchDecoration: InputDecoration(
                                suffixIcon: Icon(
                                  Icons.arrow_drop_down_rounded,
                                  size: 30,
                                  color: Theme.of(context).primaryColor,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                ),
                                isDense: true,
                                // hintText: "Amgad Hussein Ahmed",
                              ),
                              dropDownButton: SizedBox.shrink(),
                              items: ["Male", "Female"],
                              hint: "Male/Female",
                              onChanged: (gender) {
                                _genderController.text = gender;
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    SizedBox(
                      height: 80.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Age",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 52,
                            child: DropdownSearch<String>(
                              mode: Mode.MENU,
                              maxHeight: 120,
                              showSelectedItem: true,
                              dropdownSearchDecoration: InputDecoration(
                                suffixIcon: Icon(
                                  Icons.arrow_drop_down_rounded,
                                  size: 30,
                                  color: Theme.of(context).primaryColor,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(10.0),
                                  ),
                                ),
                                isDense: true,
                                // hintText: "Amgad Hussein Ahmed",
                              ),
                              dropDownButton: SizedBox.shrink(),
                              items: ["Child", "Adult", "Elder"],
                              hint: "Child",
                              onChanged: (age) {
                                _ageController.text = age;
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    SizedBox(
                      height: 80.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Governorate",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 52,
                            child: FutureBuilder<List<Governorate>>(
                              future: BlocProvider.of<ReportBloc>(context)
                                  .governorates(context),
                              builder: (context, snapshot) {
                                if (snapshot.hasData)
                                  _governorateController.text = snapshot
                                      .data[int.parse(_governorateId) - 1]
                                      .governorateNameEnglish;

                                return DropdownSearch(
                                  mode: Mode.DIALOG,
                                  maxHeight: 400,
                                  showSelectedItem: true,
                                  selectedItem: _governorateController.text,
                                  dropdownSearchDecoration: InputDecoration(
                                    suffixIcon: Icon(
                                      Icons.arrow_drop_down_rounded,
                                      size: 30,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    isDense: true,
                                  ),
                                  dropDownButton: SizedBox.shrink(),
                                  showSearchBox: true,
                                  searchBoxDecoration: InputDecoration(
                                    suffixIcon: Icon(
                                      Icons.search_sharp,
                                      size: 30,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    isDense: true,
                                  ),
                                  items: snapshot.hasData
                                      ? snapshot.data
                                          .map(
                                            (e) => e.governorateNameEnglish,
                                          )
                                          .toList()
                                      : null,
                                  onChanged: (governorate) {
                                    _governorateController.text = governorate;
                                    _governorateId = snapshot
                                        .data[snapshot.data.indexWhere(
                                      (element) =>
                                          element.governorateNameEnglish ==
                                          governorate,
                                    )]
                                        .id;
                                    _cityIndex = 0;
                                    _cityController.text = '';
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 20),
                    SizedBox(
                      height: 80.0,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "City",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(
                            height: 52,
                            child: FutureBuilder<List<City>>(
                              future: BlocProvider.of<ReportBloc>(context)
                                  .governorateCities(
                                context,
                                _governorateId,
                              ),
                              builder: (context, snapshot) {
                                if (snapshot.hasData) {
                                  _cityController.text =
                                      snapshot.data[_cityIndex].cityNameEnglish;
                                }

                                return DropdownSearch(
                                  mode: Mode.DIALOG,
                                  maxHeight: 400,
                                  showSelectedItem: true,
                                  dropdownSearchDecoration: InputDecoration(
                                    suffixIcon: Icon(
                                      Icons.arrow_drop_down_rounded,
                                      size: 30,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    isDense: true,
                                  ),
                                  dropDownButton: SizedBox.shrink(),
                                  showSearchBox: true,
                                  searchBoxDecoration: InputDecoration(
                                    suffixIcon: Icon(
                                      Icons.search_sharp,
                                      size: 30,
                                      color: Theme.of(context).primaryColor,
                                    ),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.all(
                                        Radius.circular(10.0),
                                      ),
                                    ),
                                    isDense: true,
                                  ),
                                  items: snapshot.hasData
                                      ? snapshot.data.map((e) {
                                          return e.cityNameEnglish;
                                        }).toList()
                                      : null,
                                  selectedItem: _cityController.text,
                                  onChanged: (city) {
                                    _cityController.text = city;

                                    _cityIndex = snapshot.data.indexWhere(
                                      (element) =>
                                          element.cityNameEnglish == city,
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
